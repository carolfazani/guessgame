import pygame
pygame.mixer.init()